class RandomizerEngine {
    constructor() {
        this.generators = new Map();
        this.currentGenerator = null;
        this.variables = {};
    }

    loadGenerator(id, generatorData) {
        this.generators.set(id, generatorData);
    }

    selectGenerator(id) {
        if (!this.generators.has(id)) {
            throw new Error(`Generator '${id}' not found`);
        }
        
        this.currentGenerator = this.generators.get(id);
        this.variables = {};
        
        // Initialize variables with default values
        if (this.currentGenerator.variables) {
            for (const [key, config] of Object.entries(this.currentGenerator.variables)) {
                this.variables[key] = config.default;
            }
        }
        
        return this.currentGenerator;
    }

    generate(entryPoint = 'default', count = 1) {
        if (!this.currentGenerator) {
            throw new Error('No generator selected');
        }

        const results = [];
        for (let i = 0; i < count; i++) {
            const result = this.processRule(entryPoint);
            results.push(result);
        }
        
        return results;
    }

    processRule(ruleName) {
        const grammar = this.currentGenerator.grammar;
        const entryPoints = this.currentGenerator.entry_points;
        
        // Handle entry point mapping
        let targetRule = ruleName;
        if (entryPoints && entryPoints[ruleName]) {
            targetRule = entryPoints[ruleName];
        }
        
        if (!grammar[targetRule]) {
            return `[Missing rule: ${targetRule}]`;
        }

        const rule = grammar[targetRule];
        return this.processRuleContent(rule);
    }

    processRuleContent(rule) {
        if (typeof rule === 'string') {
            return this.substituteVariables(rule);
        }

        if (Array.isArray(rule)) {
            return this.processArrayRule(rule);
        }

        if (typeof rule === 'object') {
            return this.processObjectRule(rule);
        }

        return String(rule);
    }

    processArrayRule(rule) {
        // Simple array - pick random element
        const selected = this.selectFromArray(rule);
        return this.processRuleContent(selected);
    }

    processObjectRule(rule) {
        if (rule.type === 'conditional') {
            return this.processConditionalRule(rule);
        }

        if (rule.type === 'weighted') {
            return this.processWeightedRule(rule);
        }

        // Treat as weighted object with text and weight properties
        if (rule.text !== undefined) {
            return this.processRuleContent(rule.text);
        }

        return '[Invalid rule object]';
    }

    processConditionalRule(rule) {
        // Check conditions and select appropriate option
        if (rule.options) {
            for (const option of rule.options) {
                if (this.evaluateConditions(option.conditions)) {
                    // Execute actions if present
                    if (option.actions) {
                        this.executeActions(option.actions);
                    }
                    return this.processRuleContent(option.text);
                }
            }
        }

        // Return fallback if no conditions match
        return rule.fallback ? this.processRuleContent(rule.fallback) : '[No matching condition]';
    }

    processWeightedRule(rule) {
        const options = rule.options;
        const weights = rule.weights || options.map(() => 1);
        
        const selected = this.weightedSelect(options, weights);
        return this.processRuleContent(selected);
    }

    selectFromArray(arr) {
        const processedArray = arr.map(item => {
            if (typeof item === 'object' && item.weight !== undefined) {
                return item;
            }
            return { text: item, weight: 1 };
        });

        const weights = processedArray.map(item => item.weight || 1);
        const selected = this.weightedSelect(processedArray, weights);
        
        return selected.text !== undefined ? selected.text : selected;
    }

    weightedSelect(items, weights) {
        const totalWeight = weights.reduce((sum, weight) => sum + weight, 0);
        let random = Math.random() * totalWeight;
        
        for (let i = 0; i < items.length; i++) {
            random -= weights[i];
            if (random <= 0) {
                return items[i];
            }
        }
        
        return items[items.length - 1];
    }

    evaluateConditions(conditions) {
        if (!conditions) return true;

        for (const [variable, condition] of Object.entries(conditions)) {
            const value = this.variables[variable];
            
            if (condition.$lt !== undefined && !(value < condition.$lt)) return false;
            if (condition.$lte !== undefined && !(value <= condition.$lte)) return false;
            if (condition.$gt !== undefined && !(value > condition.$gt)) return false;
            if (condition.$gte !== undefined && !(value >= condition.$gte)) return false;
            if (condition.$eq !== undefined && !(value === condition.$eq)) return false;
            if (condition.$ne !== undefined && !(value !== condition.$ne)) return false;
        }
        
        return true;
    }

    executeActions(actions) {
        if (actions.set) {
            for (const [variable, operation] of Object.entries(actions.set)) {
                if (typeof operation === 'object' && operation.$multiply) {
                    this.variables[variable] = (this.variables[variable] || 0) * operation.$multiply;
                } else {
                    this.variables[variable] = operation;
                }
            }
        }

        if (actions.increment) {
            for (const [variable, amount] of Object.entries(actions.increment)) {
                this.variables[variable] = (this.variables[variable] || 0) + amount;
            }
        }

        if (actions.decrement) {
            for (const [variable, amount] of Object.entries(actions.decrement)) {
                this.variables[variable] = (this.variables[variable] || 0) - amount;
            }
        }
    }

    substituteVariables(text) {
        return text.replace(/#([a-zA-Z_][a-zA-Z0-9_]*)#/g, (match, varName) => {
            if (this.variables.hasOwnProperty(varName)) {
                return this.variables[varName];
            }
            
            // Check if it's a grammar rule reference
            if (this.currentGenerator.grammar[varName]) {
                return this.processRule(varName);
            }
            
            return match; // Return original if not found
        });
    }

    getCurrentVariables() {
        return { ...this.variables };
    }

    getGeneratorInfo(id) {
        if (!this.generators.has(id)) return null;
        return this.generators.get(id);
    }
}

// Application Controller
class RandomizerApp {
    constructor() {
        this.engine = new RandomizerEngine();
        this.currentGeneratorId = null;
        this.isPrettyPrint = true;
        
        this.initializeGenerators();
        this.bindEvents();
        this.updateUI();
    }

    initializeGenerators() {
        // Load the provided generators
        const televangelistData = {
            "metadata": {
                "name": "Televangelist Generator",
                "version": "1.0.0",
                "description": "Generates humorous televangelist-style proclamations and money requests",
                "author": "Comedy Content Creator",
                "created": "2025-06-21",
                "category": "comedy",
                "tags": ["humor", "satire", "television", "religion"]
            },
            "variables": {
                "donation_amount": {
                    "type": "number",
                    "default": 100,
                    "description": "Current donation amount being requested"
                },
                "viewer_count": {
                    "type": "number", 
                    "default": 1000,
                    "description": "Number of viewers watching"
                },
                "miracle_count": {
                    "type": "number",
                    "default": 0,
                    "description": "Number of miracles performed this session"
                }
            },
            "grammar": {
                "greeting": [
                    "Blessed viewers!",
                    "Children of the light!",
                    "Faithful flock!",
                    "Beloved congregation!"
                ],
                "divine_title": [
                    {"text": "Reverend", "weight": 3},
                    {"text": "Pastor", "weight": 3},
                    {"text": "Minister", "weight": 2},
                    {"text": "Prophet", "weight": 1},
                    {"text": "Archbishop", "weight": 1}
                ],
                "preacher_name": [
                    "Blessington",
                    "Prosperity",
                    "Goldenshower",
                    "Moneybags",
                    "Wealthworth",
                    "Cashmere"
                ],
                "urgent_need": [
                    {"text": "the Lord's private jet", "weight": 5},
                    {"text": "a new crystal cathedral", "weight": 4},
                    {"text": "holy water imported from Jordan", "weight": 3},
                    {"text": "diamond-encrusted prayer wheels", "weight": 2},
                    {"text": "a solid gold pulpit", "weight": 1}
                ],
                "divine_consequence": [
                    "your crops will flourish",
                    "wealth will rain upon you",
                    "angels will guard your wallet",
                    "prosperity will multiply tenfold",
                    "divine financial blessings will overflow"
                ],
                "negative_consequence": [
                    {"text": "financial drought", "weight": 3},
                    {"text": "spiritual bankruptcy", "weight": 3},
                    {"text": "cursed credit score", "weight": 2},
                    {"text": "heavenly audit", "weight": 1}
                ],
                "money_request": {
                    "type": "conditional",
                    "options": [
                        {
                            "text": "Send just $#donation_amount# and #divine_consequence#!",
                            "conditions": {"donation_amount": {"$lt": 200}},
                            "actions": {"set": {"donation_amount": {"$multiply": 2}}}
                        },
                        {
                            "text": "The Lord requires $#donation_amount# for #urgent_need#!",
                            "conditions": {"donation_amount": {"$gte": 200}},
                            "actions": {"increment": {"miracle_count": 1}}
                        }
                    ],
                    "fallback": "Donations of any amount are blessed!"
                },
                "main_sermon": [
                    "#greeting# I am #divine_title# #preacher_name#, and the Lord has spoken to me! #money_request# But if you delay, beware of #negative_consequence#! Call now!"
                ]
            },
            "entry_points": {
                "default": "main_sermon",
                "alternatives": ["greeting", "money_request"]
            }
        };

        const satanicPanicData = {
            "metadata": {
                "name": "1980s Satanic Panic Generator",
                "version": "1.0.0", 
                "description": "Generates absurd 1980s-style satanic panic conspiracy theories",
                "author": "Historical Satire Writer",
                "created": "2025-06-21",
                "category": "historical-comedy",
                "tags": ["1980s", "moral-panic", "conspiracy", "satire", "history"]
            },
            "variables": {
                "panic_level": {
                    "type": "number",
                    "default": 1,
                    "description": "Current level of moral panic (1-10)"
                },
                "year": {
                    "type": "number",
                    "default": 1985,
                    "description": "Year of the panic"
                }
            },
            "grammar": {
                "innocent_activity": [
                    {"text": "playing Dungeons & Dragons", "weight": 5},
                    {"text": "listening to heavy metal", "weight": 4},
                    {"text": "reading fantasy novels", "weight": 3},
                    {"text": "playing video games", "weight": 3},
                    {"text": "watching cartoons", "weight": 2},
                    {"text": "collecting Pokemon cards", "weight": 1}
                ],
                "evil_transformation": [
                    "summoning demons",
                    "joining secret cults",
                    "sacrificing homework to dark forces",
                    "speaking in ancient tongues during math class",
                    "drawing pentagrams in notebook margins"
                ],
                "concerned_authority": [
                    {"text": "local pastor", "weight": 4},
                    {"text": "school principal", "weight": 3},
                    {"text": "PTA president", "weight": 3},
                    {"text": "concerned mother", "weight": 5},
                    {"text": "television psychologist", "weight": 2}
                ],
                "absurd_evidence": [
                    "backwards messages in Saturday morning cartoons",
                    "satanic symbols in breakfast cereal",
                    "demonic possession via calculator displays",
                    "subliminal messages in elevator music",
                    "occult rituals disguised as gym class"
                ],
                "dramatic_claim": [
                    {"text": "SHOCKING", "weight": 3},
                    {"text": "TERRIFYING", "weight": 3},
                    {"text": "UNPRECEDENTED", "weight": 2},
                    {"text": "MIND-BLOWING", "weight": 2},
                    {"text": "EARTH-SHATTERING", "weight": 1}
                ],
                "panic_headline": {
                    "type": "weighted",
                    "options": [
                        "#dramatic_claim#: Local #concerned_authority# warns that #innocent_activity# leads to #evil_transformation#!",
                        "BREAKING: #absurd_evidence# discovered in suburban neighborhood!",
                        "PARENTS BEWARE: Your children's #innocent_activity# hobby may be #evil_transformation#!",
                        "#concerned_authority# reveals #dramatic_claim# truth about #absurd_evidence#!"
                    ],
                    "weights": [4, 3, 5, 3]
                },
                "expert_quote": [
                    "According to my research, #innocent_activity# is clearly a gateway to #evil_transformation#",
                    "The signs are everywhere - #absurd_evidence# proves the influence is real",
                    "As a #concerned_authority#, I've seen firsthand how #innocent_activity# corrupts our youth"
                ]
            },
            "entry_points": {
                "default": "panic_headline",
                "alternatives": ["expert_quote", "dramatic_claim"]
            }
        };

        this.engine.loadGenerator('televangelist', televangelistData);
        this.engine.loadGenerator('satanic-panic', satanicPanicData);
    }

    bindEvents() {
        // Generator Selection
        document.getElementById('generator-select').addEventListener('change', (e) => {
            this.selectGenerator(e.target.value);
        });

        // Generation Controls
        document.getElementById('generate-btn').addEventListener('click', () => {
            this.generateText();
        });

        document.getElementById('clear-output').addEventListener('click', () => {
            this.clearOutput();
        });

        // JSON Viewer Controls
        document.getElementById('toggle-json').addEventListener('click', () => {
            this.toggleJsonViewer();
        });

        document.getElementById('pretty-print').addEventListener('click', () => {
            this.togglePrettyPrint();
        });
    }

    selectGenerator(generatorId) {
        if (!generatorId) {
            this.currentGeneratorId = null;
            this.updateUI();
            return;
        }

        try {
            this.engine.selectGenerator(generatorId);
            this.currentGeneratorId = generatorId;
            this.updateUI();
            this.showSuccess(`Generator "${this.engine.currentGenerator.metadata.name}" loaded successfully!`);
        } catch (error) {
            this.showError(`Failed to load generator: ${error.message}`);
        }
    }

    generateText() {
        if (!this.currentGeneratorId) {
            this.showError('Please select a generator first');
            return;
        }

        try {
            const count = parseInt(document.getElementById('generation-count').value) || 3;
            const entryPoint = document.getElementById('entry-point').value || 'default';
            
            const results = this.engine.generate(entryPoint, count);
            this.displayResults(results);
            this.updateVariablesDisplay();
        } catch (error) {
            this.showError(`Generation failed: ${error.message}`);
        }
    }

    displayResults(results) {
        const outputArea = document.getElementById('output-area');
        
        // Clear the placeholder text if it's the first generation
        if (outputArea.querySelector('.text-secondary')) {
            outputArea.innerHTML = '';
        }

        results.forEach((result, index) => {
            const outputItem = document.createElement('div');
            outputItem.className = 'output-item fade-in';
            
            outputItem.innerHTML = `
                <div class="output-number">Generation ${this.getNextOutputNumber()}</div>
                <div class="output-text">${result}</div>
            `;
            
            outputArea.appendChild(outputItem);
        });

        // Auto-scroll to bottom
        outputArea.scrollTop = outputArea.scrollHeight;
    }

    getNextOutputNumber() {
        const existingItems = document.querySelectorAll('.output-item').length;
        return existingItems + 1;
    }

    clearOutput() {
        const outputArea = document.getElementById('output-area');
        outputArea.innerHTML = '<p class="text-secondary">Click "Generate Text" to see results...</p>';
    }

    updateUI() {
        this.updateGeneratorInfo();
        this.updateEntryPoints();
        this.updateVariablesDisplay();
        this.updateGeneratorStructure();
        this.updateGenerateButton();
    }

    updateGeneratorInfo() {
        const infoDiv = document.getElementById('current-generator-info');
        
        if (!this.currentGeneratorId) {
            infoDiv.classList.add('hidden');
            return;
        }

        const generator = this.engine.currentGenerator;
        infoDiv.classList.remove('hidden');
        
        document.getElementById('generator-name').textContent = generator.metadata.name;
        document.getElementById('generator-description').textContent = generator.metadata.description;
        document.getElementById('generator-version').textContent = `v${generator.metadata.version}`;
        document.getElementById('generator-category').textContent = generator.metadata.category;
    }

    updateEntryPoints() {
        const select = document.getElementById('entry-point');
        select.innerHTML = '<option value="default">Default</option>';
        
        if (this.currentGeneratorId && this.engine.currentGenerator.entry_points) {
            const entryPoints = this.engine.currentGenerator.entry_points;
            
            if (entryPoints.alternatives) {
                entryPoints.alternatives.forEach(point => {
                    const option = document.createElement('option');
                    option.value = point;
                    option.textContent = point.charAt(0).toUpperCase() + point.slice(1).replace('_', ' ');
                    select.appendChild(option);
                });
            }
        }
    }

    updateVariablesDisplay() {
        const container = document.getElementById('variables-table');
        
        if (!this.currentGeneratorId) {
            container.innerHTML = '<p class="text-secondary">Select a generator to view variables</p>';
            return;
        }

        const variables = this.engine.getCurrentVariables();
        const variableConfigs = this.engine.currentGenerator.variables || {};
        
        if (Object.keys(variables).length === 0) {
            container.innerHTML = '<p class="text-secondary">No variables in this generator</p>';
            return;
        }

        let html = `
            <table class="variables-table">
                <thead>
                    <tr>
                        <th>Variable</th>
                        <th>Type</th>
                        <th>Value</th>
                        <th>Description</th>
                    </tr>
                </thead>
                <tbody>
        `;

        for (const [name, value] of Object.entries(variables)) {
            const config = variableConfigs[name] || {};
            html += `
                <tr>
                    <td class="variable-name">${name}</td>
                    <td class="variable-type">${config.type || 'unknown'}</td>
                    <td class="variable-value">${value}</td>
                    <td>${config.description || 'No description'}</td>
                </tr>
            `;
        }

        html += '</tbody></table>';
        container.innerHTML = html;
    }

    updateGeneratorStructure() {
        const container = document.getElementById('generator-structure');
        
        if (!this.currentGeneratorId) {
            container.innerHTML = '<p class="text-secondary">Select a generator to view its structure</p>';
            return;
        }

        const generator = this.engine.currentGenerator;
        const grammar = generator.grammar || {};
        const entryPoints = generator.entry_points || {};

        let html = '<div class="structure-section">';
        html += '<h4>Grammar Rules</h4>';
        html += '<ul class="structure-list">';
        
        for (const ruleName of Object.keys(grammar)) {
            html += `<li>${ruleName}</li>`;
        }
        
        html += '</ul></div>';

        html += '<div class="structure-section">';
        html += '<h4>Entry Points</h4>';
        html += '<div class="entry-points">';
        
        if (entryPoints.default) {
            html += `<span class="entry-point-tag">default: ${entryPoints.default}</span>`;
        }
        
        if (entryPoints.alternatives) {
            entryPoints.alternatives.forEach(point => {
                html += `<span class="entry-point-tag">${point}</span>`;
            });
        }
        
        html += '</div></div>';

        container.innerHTML = html;
    }

    updateGenerateButton() {
        const button = document.getElementById('generate-btn');
        button.disabled = !this.currentGeneratorId;
    }

    toggleJsonViewer() {
        const content = document.getElementById('json-content');
        const button = document.getElementById('toggle-json');
        
        if (content.classList.contains('hidden')) {
            this.showJsonViewer();
            button.textContent = 'Hide JSON';
        } else {
            content.classList.add('hidden');
            button.textContent = 'Show JSON';
        }
    }

    showJsonViewer() {
        if (!this.currentGeneratorId) {
            this.showError('Please select a generator first');
            return;
        }

        const content = document.getElementById('json-content');
        const code = document.getElementById('json-code');
        
        const generator = this.engine.getGeneratorInfo(this.currentGeneratorId);
        const jsonString = this.isPrettyPrint 
            ? JSON.stringify(generator, null, 2)
            : JSON.stringify(generator);
        
        code.textContent = jsonString;
        content.classList.remove('hidden');
    }

    togglePrettyPrint() {
        this.isPrettyPrint = !this.isPrettyPrint;
        const button = document.getElementById('pretty-print');
        button.textContent = this.isPrettyPrint ? 'Compact' : 'Pretty Print';
        
        if (!document.getElementById('json-content').classList.contains('hidden')) {
            this.showJsonViewer();
        }
    }

    showError(message) {
        this.showMessage(message, 'error');
    }

    showSuccess(message) {
        this.showMessage(message, 'success');
    }

    showMessage(message, type) {
        // Remove existing messages
        const existing = document.querySelector('.error-message, .success-message');
        if (existing) {
            existing.remove();
        }

        const messageDiv = document.createElement('div');
        messageDiv.className = `${type}-message fade-in`;
        messageDiv.textContent = message;
        
        const container = document.querySelector('.container');
        container.insertBefore(messageDiv, container.firstChild);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (messageDiv.parentNode) {
                messageDiv.remove();
            }
        }, 5000);
    }
}

// Initialize the application when the DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new RandomizerApp();
});